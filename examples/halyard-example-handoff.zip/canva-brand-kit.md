# Set up the Halyard Brand Kit in Canva

Canva Brand Kits are available on Canva Pro, Teams, Business, Enterprise, Education, and Nonprofit plans. Menu names below may differ slightly as Canva updates its interface; the values are what matter.

Open Canva, choose **Brand** in the side menu, and create a Brand Kit named **Halyard**. Then fill each area in this order.

## 1. Logos
Upload these files from the `logos/` folder. Upload the SVG where one exists (scalable, print-ready) and the PNG as a backup. Name each upload exactly as listed so people pick the right one.

| Upload as | File | Use on |
|---|---|---|
| Halyard logo: Full color | halyard-logo-light.svg (+ halyard-logo-light.png) | light backgrounds |
| Halyard logo: Knockout | halyard-logo-dark.svg (+ halyard-logo-dark.png) | dark backgrounds |
| Halyard logo: All white | halyard-logo-white.svg (+ halyard-logo-white.png) | color backgrounds |
| Halyard logo: All ink | halyard-logo-black.svg (+ halyard-logo-black.png) | light backgrounds |
| Halyard logo: Signal mark | halyard-logo-mark.svg (+ halyard-logo-mark.png) | light backgrounds |

## 2. Colors
Create one palette per group below, named as shown. Paste each HEX value exactly. Canva palettes hold HEX only, so keep this file for CMYK and Pantone values when briefing a printer.

**Palette: Halyard Primary**
- Halyard Blue: `#1F5EFF`
- Ink: `#0E1525`
- White: `#FFFFFF`

**Palette: Halyard Accent**
- Signal Coral: `#FF6B4A`
- Tide: `#14B8A6`
- Sky: `#9CC3FF`

**Palette: Halyard Neutrals**
- Mist: `#F4F6FA`
- Fog: `#E3E8F0`
- Slate 300: `#B6C0D0`
- Slate 500: `#6B778C`
- Slate 700: `#3A4458`
- Deep: `#1A2335`

## 3. Fonts
If the brand fonts are not in Canva's library, upload the licensed font files (check your license allows it). Otherwise choose the fallback shown. Set the text styles:

- **Title / Heading:** Inter Display Semi Bold, 48px
- **Subheading:** Inter Display Semi Bold, 32px
- **Body:** Inter Regular, 16px

Fallbacks: Inter Display -> Arial; Inter -> Arial

## 4. Brand voice
Paste this into the Brand Voice section so Canva's writing tools follow it:

```
Mission: Give every security team the calm, clear signal they need to act.
We sound like the most senior analyst on the team: direct, unhurried, and specific.
We are Direct, not Blunt or cold.
We are Confident, not Arrogant or absolute.
We are Plainspoken, not Jargon-heavy.
We are Calm, not Alarmist.
Lead with the outcome, then the evidence
Cite a source for every number
Never use breach headlines to sell
Say "threat", not "attack (when the tactic is unknown)".
Say "AI", not "AI and machine learning".
Say "cybersecurity", not "cyber security".
Say "sign in", not "login (as a verb)".
```

## 5. Guidelines
In the Brand Kit's guidelines area, add a short summary and do's and don'ts per category. Paste these:

**Logos**
```
Clear space: Keep a clear zone of x on every side of the logo, where x is half the height of the Signal mark. No text, imagery, or edges inside it.
Minimum size: print 1 in / 25 mm wide; digital 120 px wide; mark only 16 px
Don't: stretch or distort the logo
Don't: rotate, angle, or skew the logo
Don't: recolor the logo or use unapproved colors
Don't: add drop shadows, glows, or other effects
Don't: outline or stroke the logo
Don't: place the logo on busy backgrounds or patterns
Don't: use the light-mode logo on dark backgrounds
Don't: crowd the logo or ignore its clear space
Don't: use the Signal mark as a bullet point or decorative icon
Don't: animate the wave without the approved motion file
Don't: place the logo on competitor-hosted or competitor-sponsored materials
Don't: place the logo on merchandise without marketing approval
Don't: place the logo next to breach news imagery or hacker stock photos
Don't: place the logo in a partner's product UI without a signed agreement
```

**Colors**
```
White / Mist: about 55% of a layout
Ink: about 25% of a layout
Halyard Blue: about 15% of a layout
Coral: about 5% of a layout
Don't: tint or shade brand colors outside the defined neutrals
Don't: set body text in Signal Coral
Don't: place Halyard Blue text on Ink
```

**Fonts**
```
Sentence case for all headlines
Headlines in Ink, White, or Halyard Blue only
Left-align body copy; never justify
Don't: use more than two weights in one layout
Don't: set body copy below 14 px on screen
```

**Photos**
```
Real practitioners at work, in natural light.
Don't: hooded hackers or green code rain
Don't: padlocks, shields, and stock 'cyber' clichés
Don't: staged handshakes
```

## 6. Lock it down
If you are a Brand Kit admin, restrict editing of the kit and set brand controls so teammates can only use kit colors and fonts. Then make a template from one of the deck's slides to test the kit.
