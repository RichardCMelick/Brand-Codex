# Halyard Brand Guidelines

Version 1.0 | October 2026

This guide shows how to present the Halyard brand consistently. It is for employees, agencies, partners, and AI design tools. The rules are fixed; creativity inside them is encouraged.

> Instructions for AI design tools: treat every value in this file as fixed. Use only the listed colors, typefaces, and logo files. Follow every "Do not" rule. If a request conflicts with this guide, follow the guide and say what you changed.

## Brand foundation

**Mission:** Give every security team the calm, clear signal they need to act.

**Vision:** A world where security teams spend their time deciding, not searching.

**Tagline:** Signal over noise.

**Positioning:** Halyard is the detection platform that turns noisy telemetry into a short, ranked list of what matters, so lean security teams act first and explain later.

**Boilerplate:** Halyard helps security teams cut through alert noise. The Halyard platform correlates signals across cloud, identity, and endpoint to surface the handful of threats that matter, ranked and explained. Founded in 2021 and headquartered in Denver, Colorado, Halyard protects more than 400 organizations. Learn more at halyard.example.

**Direction:** Over the next two years we are moving from a detection tool to the system of record for security decisions. The brand should feel more like a trusted instrument than a startup.

### Pillar: Clarity
We say the useful thing first.
- Ranked, explained findings
- Plain language over jargon
- No dashboards for their own sake

### Pillar: Calm
Security without the siren.
- No fear-based selling
- Confident, steady tone
- Evidence over adjectives

### Pillar: Craft
Built by practitioners.
- Designed with SOC analysts
- Opinionated defaults
- Fast to deploy

### Voice and tone

We sound like the most senior analyst on the team: direct, unhurried, and specific.

| We are | We are not |
|---|---|
| Direct | Blunt or cold |
| Confident | Arrogant or absolute |
| Plainspoken | Jargon-heavy |
| Calm | Alarmist |

- Lead with the outcome, then the evidence
- Cite a source for every number
- Never use breach headlines to sell

## Logo

The Halyard logo pairs the Signal mark, a wave rising inside a circle, with our wordmark. The two always appear together in the approved relationship.

| Version | File | Use on | Usage |
|---|---|---|---|

| Full color (preferred) | logos/halyard-logo-light.svg (+ halyard-logo-light.png) | light backgrounds | Default. White and light gray backgrounds. |

| Knockout | logos/halyard-logo-dark.svg (+ halyard-logo-dark.png) | dark backgrounds | Ink and other dark backgrounds. |

| All white | logos/halyard-logo-white.svg (+ halyard-logo-white.png) | color backgrounds | On Halyard Blue only. |

| All ink | logos/halyard-logo-black.svg (+ halyard-logo-black.png) | light backgrounds | One-color print and engraving. |

| Signal mark | logos/halyard-logo-mark.svg (+ halyard-logo-mark.png) | light backgrounds | Favicons and avatars where the full logo will not fit. |

**Clear space:** Keep a clear zone of x on every side of the logo, where x is half the height of the Signal mark. No text, imagery, or edges inside it.

**Small sizes:** At favicon sizes the mark may fill up to 90% of the canvas.

**Minimum size:** print 1 in / 25 mm wide; digital 120 px wide; mark only 16 px

### Logo: do not
- Do not stretch or distort the logo
- Do not rotate, angle, or skew the logo
- Do not recolor the logo or use unapproved colors
- Do not add drop shadows, glows, or other effects
- Do not outline or stroke the logo
- Do not place the logo on busy backgrounds or patterns
- Do not use the light-mode logo on dark backgrounds
- Do not crowd the logo or ignore its clear space
- Do not use the Signal mark as a bullet point or decorative icon
- Do not animate the wave without the approved motion file

### Where the logo never appears
- On competitor-hosted or competitor-sponsored materials
- On merchandise without marketing approval
- Next to breach news imagery or hacker stock photos
- In a partner's product UI without a signed agreement

## Co-branding
When Halyard appears with a partner, both brands should look like equals.

- **Order:** Halyard first in Halyard-led materials; partner first in theirs.
- **Balance:** Match visual weight, not pixel width.
- **Alignment:** Center-align on a shared axis.
- **Mode:** Both logos in the same mode.

**Separator between logos:** line

**Minimum gap:** 0.5 in / 48 px between logos

### Co-branding: do not
- Do not convert the Halyard logo to grayscale to match a partner
- Do not give either logo visual dominance
- Do not create a combined lockup

## Color

### Primary
Halyard Blue and Ink carry the brand. Use them for logo, headlines, and large color fields.

| Name | HEX | RGB | CMYK | Pantone | Role |
|---|---|---|---|---|---|

| Halyard Blue | #1F5EFF | 31, 94, 255 | 85, 63, 0, 0 | 2728 C |  |

| Ink | #0E1525 | 14, 21, 37 | 86, 75, 49, 72 | Black 6 C |  |

| White | #FFFFFF | 255, 255, 255 | 0, 0, 0, 0 |  |  |

### Accent
Use sparingly for calls to action, highlights, and charts. Never as a background behind body text.

| Name | HEX | RGB | CMYK | Pantone | Role |
|---|---|---|---|---|---|

| Signal Coral | #FF6B4A | 255, 107, 74 |  | 2028 C | CTAs and highlights |

| Tide | #14B8A6 | 20, 184, 166 |  | 3268 C | Success, charts |

| Sky | #9CC3FF | 156, 195, 255 |  | 2706 C | Links on dark |

### Neutrals
Structure: backgrounds, borders, dividers, tables, and body copy.

| Name | HEX | RGB | CMYK | Pantone | Role |
|---|---|---|---|---|---|

| Mist | #F4F6FA | 244, 246, 250 |  |  |  |

| Fog | #E3E8F0 | 227, 232, 240 |  |  |  |

| Slate 300 | #B6C0D0 | 182, 192, 208 |  |  |  |

| Slate 500 | #6B778C | 107, 119, 140 |  |  |  |

| Slate 700 | #3A4458 | 58, 68, 88 |  |  |  |

| Deep | #1A2335 | 26, 35, 53 |  |  |  |

### Light and dark mode

| Token | Light | Dark |
|---|---|---|

| background | White (#FFFFFF) | Ink (#0E1525) |

| surface | Mist (#F4F6FA) | Deep (#1A2335) |

| text | Ink (#0E1525) | White (#FFFFFF) |

| text_muted | Slate 500 (#6B778C) | Slate 300 (#B6C0D0) |

| border | Fog (#E3E8F0) | Slate 700 (#3A4458) |

| accent | Halyard Blue (#1F5EFF) | Halyard Blue (#1F5EFF) |

| link | Halyard Blue (#1F5EFF) | Sky (#9CC3FF) |

| logo_variant | light | dark |

- Light mode body text contrast: 18.2:1 (AAA)

- Dark mode body text contrast: 18.2:1 (AAA)

### Proportion
- White / Mist: 55% (Space and backgrounds)
- Ink: 25% (Type and dark sections)
- Halyard Blue: 15% (Brand moments)
- Coral: 5% (Actions only)

### Gradients
One gradient only, Halyard Blue to Ink, at 135 degrees. Use for hero backgrounds, never behind small text.
- Depth: #1F5EFF to #0E1525 at 135 degrees

### Color: do not
- Do not tint or shade brand colors outside the defined neutrals
- Do not set body text in Signal Coral
- Do not place Halyard Blue text on Ink

## Typography

- **Inter Display** (headline): Headlines and display numbers. Weights: Medium, Semi Bold, Bold. Fallback: Arial. Source: Open source (SIL OFL), rsms.me/inter.

- **Inter** (body): Body copy, UI, tables, and captions. Weights: Regular, Italic, Medium, Semi Bold. Fallback: Arial. Source: Open source (SIL OFL).

| Level | Family | Weight | Size | Line height | Tracking | Case |
|---|---|---|---|---|---|---|

| Eyebrow | Inter | Semi Bold | 12px |  | 8% | uppercase |

| H1 | Inter Display | Semi Bold | 48px | 1.1 |  |  |

| H2 | Inter Display | Semi Bold | 32px | 1.2 |  |  |

| H3 | Inter Display | Medium | 24px | 1.25 |  |  |

| Lead | Inter | Regular | 20px | 1.5 |  |  |

| Body | Inter | Regular | 16px | 1.6 |  |  |

| Caption | Inter | Medium | 12px | 1.4 |  |  |

- Sentence case for all headlines
- Headlines in Ink, White, or Halyard Blue only
- Left-align body copy; never justify

### Typography: do not
- Use more than two weights in one layout
- Set body copy below 14 px on screen

## Photography
Real practitioners at work, in natural light.

- **Real people:** Candid, never posed.
- **Natural light:** Daylight, soft shadows.
- **Calm focus:** Concentration, not panic.

### Photography: avoid
- Hooded hackers or green code rain
- Padlocks, shields, and stock 'cyber' clichés
- Staged handshakes

## Writing style

Base style guide: the AP Stylebook.

### Names
- Halyard, never HALYARD or Halyard Labs
- The Halyard platform on first reference, then Halyard
- Do not add 'Halyard' in front of feature names

| Use | Instead of | Note |
|---|---|---|
| threat | attack (when the tactic is unknown) | Broader and more accurate |
| AI | AI and machine learning | Redundant together |
| cybersecurity | cyber security | One word |
| sign in | login (as a verb) | Login is a noun |

### Formatting
- Always use the Oxford comma
- Never use & or + in place of 'and' in body copy
- Dates: October 28, 2026
- Phone: +1-303-555-0100

## Governance

Files: brand.halyard.example (logos, fonts, templates)

- Brand approvals: Brand team brand@halyard.example
