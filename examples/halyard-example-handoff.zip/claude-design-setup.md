# Load the Halyard brand into Claude Design and Claude

This kit gives Claude everything it needs to produce on-brand work without
guessing. Three files carry the brand:

| File | What it is |
|---|---|
| `brand-guidelines.md` | The complete written guide, including every "do not" rule. Self-contained. |
| `design-tokens.json` | Colors, light/dark mode roles, fonts, and type scale in the W3C Design Tokens format. |
| `tokens.css` | The same tokens as CSS variables, with a dark theme. |
| `logos/` | Every approved logo file, with transparent PNG exports. |

## Claude Design

Claude Design works from a design system. Create a new design system for
Halyard and add these files to it by upload (or commit them to the GitHub
repository you import from):

1. `design-tokens.json` and `tokens.css` (colors, modes, typography)
2. `brand-guidelines.md` (rules, voice, and don'ts)
3. All files in `logos/`
4. The brand font files, if your license permits sharing them

If your organization has admins, have one approve the system as the standard
so teammates start from it by default. Interface details change; if a menu
is named differently, the goal is the same: the tokens, guide, and logos
live in one design system that every new design uses.

Starter prompt to test it:

```
Using the Halyard design system, make a one-page event flyer in light mode.
Follow brand-guidelines.md exactly: use only listed colors and typefaces,
the correct logo version for the background, and respect clear space.
List any rule you could not follow.
```

## Claude (chat, Projects, Claude Code)

- **Projects:** add `brand-guidelines.md`, `design-tokens.json`, and the logo
  PNGs to the project's knowledge. Add this to the project instructions:
  "All visual and written output follows brand-guidelines.md. Never invent
  colors or fonts."
- **Claude Code:** commit `tokens.css` and `design-tokens.json` to the repo
  and reference them from your stylesheet. Put a pointer to
  `brand-guidelines.md` in the repo's CLAUDE.md.
- **Any other AI tool:** paste `brand-guidelines.md` as context. It opens
  with instructions written for AI tools.
